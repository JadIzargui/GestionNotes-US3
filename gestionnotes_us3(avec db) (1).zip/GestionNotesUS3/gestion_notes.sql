-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 15 nov. 2025 à 22:10
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_notes`
--

-- --------------------------------------------------------

--
-- Structure de la table `etudiants`
--

CREATE TABLE `etudiants` (
  `id` int(11) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `nom` varchar(255) NOT NULL,
  `moyenne` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `etudiants`
--

INSERT INTO `etudiants` (`id`, `prenom`, `nom`, `moyenne`) VALUES
(1, 'Jean', 'Dupont', 15.00),
(2, 'Marie', 'Curie', 19.50),
(3, 'Jean', 'Dupont', 15.17),
(4, 'Jean', 'Dupont', 15.17),
(5, 'Jean', 'Dupont', 15.17),
(6, 'Jean', 'Dupont', 15.17),
(7, 'Jean', 'Dupont', 15.17);

-- --------------------------------------------------------

--
-- Structure de la table `notations`
--

CREATE TABLE `notations` (
  `id` int(11) NOT NULL,
  `etudiant_id` int(11) NOT NULL,
  `matiere` varchar(255) NOT NULL,
  `note` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `notations`
--

INSERT INTO `notations` (`id`, `etudiant_id`, `matiere`, `note`) VALUES
(1, 1, 'Mathématiques', 15.00),
(2, 1, 'Physique', 12.00),
(3, 1, 'Français', 18.00),
(4, 2, 'Physique', 19.00),
(5, 2, 'Chimie', 20.00),
(6, 2, 'TP Précédent', NULL),
(7, 3, 'Mathématiques', 15.00),
(8, 3, 'Physique', 12.50),
(9, 3, 'Fran?ais', 18.00),
(10, 3, 'TP Précédent', NULL),
(11, 4, 'Mathématiques', 15.00),
(12, 4, 'Physique', 12.50),
(13, 4, 'Fran?ais', 18.00),
(14, 4, 'TP Précédent', NULL),
(15, 5, 'Mathématiques', 15.00),
(16, 5, 'Physique', 12.50),
(17, 5, 'Fran?ais', 18.00),
(18, 5, 'TP Précédent', NULL),
(19, 6, 'Mathématiques', 15.00),
(20, 6, 'Physique', 12.50),
(21, 6, 'Fran?ais', 18.00),
(22, 6, 'TP Précédent', NULL),
(23, 7, 'Mathématiques', 15.00),
(24, 7, 'Physique', 12.50),
(25, 7, 'Fran?ais', 18.00),
(26, 7, 'TP Précédent', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `etudiants`
--
ALTER TABLE `etudiants`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notations`
--
ALTER TABLE `notations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `etudiant_id` (`etudiant_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `etudiants`
--
ALTER TABLE `etudiants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `notations`
--
ALTER TABLE `notations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `notations`
--
ALTER TABLE `notations`
  ADD CONSTRAINT `notations_ibfk_1` FOREIGN KEY (`etudiant_id`) REFERENCES `etudiants` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
