package gestionnotes;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Etudiant {
    private int id;
    private String nom;
    private String prenom; 
    private double moyenne;
    private List<Notation> notations;

    
    public Etudiant(String nom, String prenom) {
        this.nom = nom;
        this.prenom = prenom;
        this.notations = new ArrayList<>();
    }

    
    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; } 
    public List<Notation> getNotations() { return notations; }
    public double getMoyenne() { return moyenne; }

    /**
     * Sauvegarde un nouvel étudiant dans la base de données.
     */
    public void sauvegarder() throws SQLException {
        
        String sql = "INSERT INTO etudiants (nom, prenom) VALUES (?, ?)";
        try (Connection conn = DataBaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, this.nom);
            pstmt.setString(2, this.prenom); 
            pstmt.executeUpdate();
            
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    this.id = generatedKeys.getInt(1);
                }
            }
        }
    }

    
    public void ajouterNote(Notation notation) throws SQLException {
        String sql = "INSERT INTO notations (etudiant_id, matiere, note) VALUES (?, ?, ?)";
        try (Connection conn = DataBaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, this.id);
            pstmt.setString(2, notation.getMatiere());
            if (notation.getNote() != null) {
                pstmt.setDouble(3, notation.getNote());
            } else {
                pstmt.setNull(3, Types.DECIMAL);
            }
            pstmt.executeUpdate();
            this.notations.add(notation);
        }
    }

    public void calculerEtMettreAJourMoyenne() throws SQLException {
        double total = 0;
        int count = 0;
        for (Notation n : this.notations) {
            if (n.getNote() != null) {
                total += n.getNote();
                count++;
            }
        }
        this.moyenne = (count > 0) ? total / count : 0;
        String sql = "UPDATE etudiants SET moyenne = ? WHERE id = ?";
        try (Connection conn = DataBaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDouble(1, this.moyenne);
            pstmt.setInt(2, this.id);
            pstmt.executeUpdate();
        }
    }

    public static Etudiant recupererParId(int studentId) throws SQLException {
        String sqlEtudiant = "SELECT * FROM etudiants WHERE id = ?";
        Etudiant etudiant = null;
        try (Connection conn = DataBaseManager.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sqlEtudiant)) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // On récupère le nom ET le prénom
                etudiant = new Etudiant(rs.getString("nom"), rs.getString("prenom"));
                etudiant.id = rs.getInt("id");
                etudiant.moyenne = rs.getDouble("moyenne");
                String sqlNotations = "SELECT * FROM notations WHERE etudiant_id = ?";
                try (PreparedStatement pstmtNotes = conn.prepareStatement(sqlNotations)) {
                    pstmtNotes.setInt(1, studentId);
                    ResultSet rsNotes = pstmtNotes.executeQuery();
                    while(rsNotes.next()) {
                        Double noteVal = rsNotes.getObject("note") != null ? rsNotes.getDouble("note") : null;
                        Notation notation = new Notation(rsNotes.getString("matiere"), noteVal);
                        notation.setId(rsNotes.getInt("id"));
                        etudiant.notations.add(notation);
                    }
                }
            }
        }
        return etudiant;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- Informations de l'étudiant ---\n");
        sb.append("ID: ").append(id).append("\n");
        
        sb.append("Nom complet: ").append(prenom).append(" ").append(nom).append("\n");
        sb.append(String.format("Moyenne: %.2f\n", moyenne));
        sb.append("Notes:\n");
        if (notations.isEmpty()) {
            sb.append("  Aucune note enregistrée.\n");
        } else {
            for (Notation n : notations) {
                sb.append("  - ").append(n).append("\n");
            }
        }
        return sb.toString();
    }
}