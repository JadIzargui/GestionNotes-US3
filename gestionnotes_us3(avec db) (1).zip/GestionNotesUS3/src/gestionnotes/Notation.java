package gestionnotes;

public class Notation {
    private int id;
    private String matiere;
    private Double note; 

    public Notation(String matiere, Double note) {
        this.matiere = matiere;
        this.note = note;
    }

    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getMatiere() { return matiere; }
    public void setMatiere(String matiere) { this.matiere = matiere; }
    public Double getNote() { return note; }
    public void setNote(Double note) { this.note = note; }

    @Override
    public String toString() {
        return "Matière: " + matiere + ", Note: " + (note != null ? note : "Nulle (non rendu)");
    }
}