package gestionnotes;

import java.sql.SQLException;

public class TestEtudiant {

    public static void main(String[] args) {
        try {
            
            System.out.println("Création de l'étudiant Jean Dupont...");
            
            
            Etudiant jean = new Etudiant("Dupont", "Jean"); 
            
            jean.sauvegarder();
            System.out.println("Étudiant créé avec l'ID: " + jean.getId());

            System.out.println("\nAjout des notes...");
            jean.ajouterNote(new Notation("Mathématiques", 15.0));
            jean.ajouterNote(new Notation("Physique", 12.5));
            jean.ajouterNote(new Notation("Français", 18.0));
            jean.ajouterNote(new Notation("TP Précédent", null));
            System.out.println("Notes ajoutées.");

            
            System.out.println("\nCalcul de la moyenne...");
            jean.calculerEtMettreAJourMoyenne();
            System.out.println("Moyenne calculée et mise à jour dans la base.");

            
            System.out.println("\nRécupération et affichage des informations depuis la base...");
            Etudiant etudiantRecupere = Etudiant.recupererParId(jean.getId());

            if (etudiantRecupere != null) {
                System.out.println(etudiantRecupere);
            } else {
                System.out.println("Impossible de retrouver l'étudiant.");
            }

        } catch (SQLException e) {
            System.err.println("Une erreur de base de données est survenue.");
            e.printStackTrace();
        }
    }
}